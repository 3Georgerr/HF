Pro informace jak instalovat knihovny se pod�vej na: http://www.arduino.cc/en/Guide/Libraries
